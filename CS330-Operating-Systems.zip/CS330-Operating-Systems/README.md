# CS330 Operating Systems
This repository contains all of my assignment solutions for the Operating Systems (CS330A) course at IIT Kanpur, Fall Semester - 2020, instructed by Prof. Debadatta Mishra. Last three assignments were done on gemOS, a simple educational OS for gem5 architectural simulator.
